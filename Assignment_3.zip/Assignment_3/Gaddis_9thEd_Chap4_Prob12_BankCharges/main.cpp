/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Display bank service fees for the month based on beginning balance and checks written
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format library
using namespace std;

//Execution begins here
int main(int argc, char **argv)
{
    //Declare  Variables here
    int
        balFee,  //fee is balance is below $400
        mnthFee, //monthly fee
        chkCnt;  //check count
    float
        feeRate, //fee rate
        chkFee,  //check fee
        strtBal, //starting balance
        crrtBal; //starting balance

    //Initialize Variables here
    cout << "Monthly Bank Fees" << endl;
    cout << "Input Current Bank Balance and Number of Checks" << endl;
    cin >> strtBal >> chkCnt;
    if (strtBal < 0) cout << "Account is overdrawn" << endl; //display overdraft warning if account is below zero
    mnthFee = 10; //monthly fee

    //Map inputs/knowns to the output
    balFee = strtBal < 400 ? 15 : 0; //add $15 to the service fee if user has a balance of less than $400
    //calculate fee rate based on checks written
    feeRate = chkCnt < 20                  ? 0.10 :
              chkCnt >= 20 && chkCnt <= 39 ? 0.08 :
              chkCnt >= 40 && chkCnt <= 59 ? 0.06 : 0.04;
    chkFee  = feeRate * chkCnt; //find the check fee
    crrtBal = strtBal - mnthFee - balFee - chkFee;  //find currnent balance

    //Display Output
    cout << fixed << setprecision(2) << showpoint;
    cout << "Balance     $" << setw(9) << strtBal << endl;
    cout << "Check Fee   $" << setw(9) << chkFee << endl;
    cout << "Monthly Fee $" << setw(9) << static_cast<float>(mnthFee) << endl;
    cout << "Low Balance $" << setw(9) << static_cast<float>(balFee) << endl;
    cout << "New Balance $" << setw(9) << crrtBal;

    //Exit the program
    return 0;
}

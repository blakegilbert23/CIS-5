/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Write a program that determines how many points were earned for buying books.
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format library
using namespace std;

//Execution begins here
int main(int argc, char **argv)
{
    //Declare  Variables here
    int
        bksPrch, //books purchased
        ttlPnts; //total points

    //Initialize Variables here
    cout << "Book Worm Points" << endl;
    cout << "Input the number of books purchased this month." << endl;
    cin >> bksPrch;
    ttlPnts = 0;

    //Map inputs/knowns to the output
    // determine points based on books purchased
    ttlPnts = bksPrch == 0 ? 4 :
              bksPrch == 1 ? 5 :
              bksPrch == 2 ? 15 :
              bksPrch == 3 ? 30 : 60;

    //Display Output
    cout << "Books purchased = " << setw(2) << bksPrch << endl;
    cout << "Points earned   = " << setw(2) << ttlPnts;

    //Exit the program
    return 0;
}

/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Sort inputted names
 */

//System Level Libraries
#include <iostream>  //Input-Output Library
#include <iomanip>   //Format Library
#include <string>    //String Library
#include <vector>    //Vector Library
#include <algorithm> //Algorithm Library
using namespace std;

//Execution begins here
int main(int argc, char **argv)
{
    //Declare  Variables here
    string name1, name2, name3; //user-entered names
    vector<string> allNmes;     //array containing all names

    //Initialize Variables here
    cout << "Sorting Names" << endl;
    cout << "Input 3 names" << endl;
    cin >> name1 >> name2 >> name3;
    //push user inputs into array that stores all names
    allNmes.push_back(name1);
    allNmes.push_back(name2);
    allNmes.push_back(name3);

    //Map inputs/knowns to the output
    sort(allNmes.begin(), allNmes.end());

    //loop through array containing all names and output them to the console.
    //remove endline from final output
    for (int i = 0; i < allNmes.size(); i++)
    {
        i != (allNmes.size() - 1)
            ? cout << allNmes[i] << endl
            : cout << allNmes[i];
    }

    //Exit the program
    return 0;
}

/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 14, 2022, 8:46 PM
 * Purpose: Calculate monthly internet bill
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format Library
using namespace std;

//Execution begins here
int main(int argc, char **argv)
{
    //Declare  Variables here
    char pckge;
    float hours, bill, ot;

    //Initialize Variables here
    cout << "ISP Bill" << endl;
    cout << "Input Package and Hours" << endl;
    cin >> pckge >> hours;

    //Map inputs/knowns to the output
    //calculate bill based on package and hours used
    switch(pckge){
        case 'A': bill = hours > 10 ?  9.95 + ((hours - 10) * 2.00) :  9.95; break;
        case 'B': bill = hours > 20 ? 14.95 + ((hours - 20) * 1.00) : 14.95; break;
        default: bill = 19.95;
    }

    //Display Output
    cout << fixed << setprecision(2);
    cout << "Bill = $" << setw(6) << bill;

    //Exit the program
    return 0;
}

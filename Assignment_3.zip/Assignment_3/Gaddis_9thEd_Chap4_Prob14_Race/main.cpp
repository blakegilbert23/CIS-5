/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Sort runners by their race times
 */

//System Level Libraries
#include <iostream>  //Input-Output Library
#include <iomanip>   //Format Library
#include <string>    //String Library
#include <vector>    //Vector Library
#include <algorithm> //Algorithm Library
using namespace std;

//Execution begins here
int main(int argc, char **argv)
{
    //Declare  Variables here
    string r1Name, r2Name, r3Name;
    string fName, sName, tName;
    int r1Time, r2Time, r3Time;
    int fTime, sTime, tTime;
    vector<int> allTmes;

    //Initialize Variables here
    cout << "Race Ranking Program" << endl;
    cout << "Input 3 Runners" << endl;
    cout << "Their names, then their times" << endl;
    cin >> r1Name >> r1Time;
    cin >> r2Name >> r2Time;
    cin >> r3Name >> r3Time;
    //push runners time into an array
    allTmes.push_back(r1Time);
    allTmes.push_back(r2Time);
    allTmes.push_back(r3Time);
    //sort array by fastest speed
    sort(allTmes.begin(), allTmes.end());

    //Map inputs/knowns to the output
    //sort runners by time
    fName = allTmes[0] == r1Time ? r1Name :
            allTmes[0] == r2Time ? r2Name : r3Name;
    sName = allTmes[1] == r1Time ? r1Name :
            allTmes[1] == r2Time ? r2Name : r3Name;
    tName = allTmes[2] == r1Time ? r1Name :
            allTmes[2] == r2Time ? r2Name : r3Name;
    //match runners time with runners name
    fTime = fName == r1Name ? r1Time :
            fName == r2Name ? r2Time : r3Time;
    sTime = sName == r1Name ? r1Time :
            sName == r2Name ? r2Time : r3Time;
    tTime = tName == r1Name ? r1Time :
            tName == r2Name ? r2Time : r3Time;

    //Display Output
    cout << fName << "\t" << setw(3) << fTime << endl;
    cout << sName << "\t" << setw(3) << sTime << endl;
    cout << tName << "\t" << setw(3) << tTime;

    //Exit the program
    return 0;
}

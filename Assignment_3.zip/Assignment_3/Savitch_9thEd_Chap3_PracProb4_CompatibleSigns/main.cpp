/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Determine if two Astrology signs are compatible.
 */

//System Level Libraries
#include <iostream>  //Input-Output Library
#include <iomanip>   //Format Library
#include <string>    //String Library
#include <algorithm> //Algorithm Library
using namespace std;

//Execution begins here
int main(int argc, char **argv)
{
    //Declare  Variables here
    string sign1, sign2, type1, type2;

    //Initialize Variables here
    cout << "Horoscope Program which examines compatible signs." << endl;
    cout << "Input 2 signs." << endl;
    cin >> sign1 >> sign2;

    //Map inputs/knowns to the output
    //find type of sign 1
    if (sign1 == "Aries"  || sign1 == "Leo"     || sign1 == "Sagittarius") type1  = "Fire";
    if (sign1 == "Taurus" || sign1 == "Virgo"   || sign1 == "Capricorn")   type1  = "Earth";
    if (sign1 == "Gemini" || sign1 == "Libra"   || sign1 == "Aquarius")    type1  = "Air";
    if (sign1 == "Cancer" || sign1 == "Scorpio" || sign1 == "Pisces")      type1  = "Water";
    //find type of sign 2
    if (sign2 == "Aries"  || sign2 == "Leo"     || sign2 == "Sagittarius") type2  = "Fire";
    if (sign2 == "Taurus" || sign2 == "Virgo"   || sign2 == "Capricorn")   type2  = "Earth";
    if (sign2 == "Gemini" || sign2 == "Libra"   || sign2 == "Aquarius")    type2  = "Air";
    if (sign2 == "Cancer" || sign2 == "Scorpio" || sign2 == "Pisces")      type2  = "Water";

    //Display Output
    type1 == type2
        ? cout << sign1 << " and " << sign2 << " are compatible " << type1 << " signs."
        : cout << sign1 << " and " << sign2 << " are not compatible signs.";

    //Exit the program
    return 0;
}

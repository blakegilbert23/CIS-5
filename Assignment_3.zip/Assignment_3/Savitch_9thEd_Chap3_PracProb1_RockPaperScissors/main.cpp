/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Rock, Paper, Scissors game.
 * Players choose options by entering the first letter of the option.
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format Library
#include <string>   // String Library
using namespace std;

//Execution begins here
int main(int argc, char **argv)
{
    //Declare  Variables here
    char
        rck,    //choice option
        ppr,    //choice option
        scr,    //choice option
        p1Chce, //player1 guess
        p2Chce; //player2 guess
    string
        rckWins, //message when rock wins
        pprWins, //message when paper wins
        scrWins, //message when scissor wins
        tieGame, //output message when game ties
        outcome; //outcome of game

    //Initialize Variables here
    cout << "Rock Paper Scissors Game" << endl;
    cout << "Input Player 1 and Player 2 Choices" << endl;
    cin >> p1Chce >> p2Chce;
    //convert letters to game options
    rck = 'r';
    ppr = 'p';
    scr = 's';
    //game outcomes
    rckWins = "Rock breaks scissors.";
    pprWins = "Paper covers rock.";
    scrWins = "Scissors cuts paper.";
    tieGame = "It's a tie.";

    //Map inputs/knowns to the output
    //determine outcome of game
    switch (tolower(p1Chce)) {
        case 'r': outcome = tolower(p2Chce) == rck ? tieGame :
                            tolower(p2Chce) == ppr ? pprWins : rckWins; break;
        case 'p': outcome = tolower(p2Chce) == rck ? pprWins :
                            tolower(p2Chce) == ppr ? tieGame : scrWins; break;
        case 's': outcome = tolower(p2Chce) == rck ? rckWins :
                            tolower(p2Chce) == ppr ? scrWins : tieGame; break;
    }

    //Display Output
    cout << outcome;

    //Exit the program
    return 0;
}

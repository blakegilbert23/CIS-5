/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 4, 2022, 8:46 PM
 * Purpose: Find the sales tax on a purchase
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        prchse, //cost of purchase

        sst, //state sales tax
        cst, //county sales tax
        tst; //total sales tax

    //Initialize Variables here
    prchse = 95;
    sst = 0.04;
    cst = 0.02;

    //Map inputs/knowns to the output
    tst = prchse * (sst + cst);

    //Display Output
    cout << fixed << setprecision(2) << endl;

    cout << "The total sales tax on a $95 purchase would be $" << tst << endl;

    //Exit the program
    return 0;
}

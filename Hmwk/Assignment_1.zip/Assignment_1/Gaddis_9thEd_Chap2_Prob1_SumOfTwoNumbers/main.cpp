/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 5th, 2022, 5:00 PM
 * Purpose: Find the sum of 2 numbers
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here
//Global constants are recognized constants from the sciences
//Physics, Chemistry, Engineering,  and Conversions between systems of units

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    int num1, num2, total;

    //Initialize Variables here
    num1 = 50;
    num2 = 100;

    //Map inputs/knowns to the output
    total = num1 + num2;

    //Display Output
    cout << "Num1 = " << num1 << endl;
    cout << "Num2 = " << num2 << endl;
    cout << "Num1 + Num2 = " << total << endl;

    //Exit the program
    return 0;
}

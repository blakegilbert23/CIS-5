/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 4, 2022, 8:46 PM
 * Purpose: Find the difference in ocean levels over the course of 10 years
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        yrlyDif, //change per year in mm

        difIn5,  //total change in 5 years in mm
        difIn7,  //total change in 7 years in mm
        difIn10; //total change in 10 years in mm

    //Initialize Variables here
    yrlyDif = 1.5;

    //Map inputs/knowns to the output
    difIn5 = yrlyDif * 5;
    difIn7 = yrlyDif * 7;
    difIn10 = yrlyDif * 10;

    //Display Output
    cout << "In 5 years, the ocean's level will be " << difIn5 << "mm higher than it is now." << endl;
    cout << "In 7 years, the ocean's level will be " << difIn7 << "mm higher than it is now." << endl;
    cout << "In 10 years, the ocean's level will be " << difIn10 << "mm higher than it is now." << endl;

    //Exit the program
    return 0;
}

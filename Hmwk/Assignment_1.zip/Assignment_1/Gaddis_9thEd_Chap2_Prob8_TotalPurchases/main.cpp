/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 4, 2022, 8:46 PM
 * Purpose: All projects start by using the CPP template. It shows where to place your project
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //used to setprecision
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        item1, //cost of item 1
        item2, //cost of item 2
        item3, //cost of item 3
        item4, //cost of item 4
        item5, //cost of item 5

        subTtl, //subtotal
        slsTax, //sales tax
        total;  //total after everything

    //Initialize Variables here
    item1 = 15.95;
    item2 = 24.95;
    item3 = 6.95;
    item4 = 12.95;
    item5 = 3.95;

    //Map inputs/knowns to the output
    subTtl = item1 + item2 + item3 + item4 + item5;
    slsTax = subTtl * 0.07;
    total = subTtl + slsTax;

    //Display Output
    cout << fixed << setprecision(2) << endl;

    cout << "Item 1: $" << item1 << endl;
    cout << "Item 2: $" << item2 << endl;
    cout << "Item 3: $" << item3 << endl;
    cout << "Item 4: $" << item4 << endl;
    cout << "Item 5: $" << item5 << endl;
    cout << endl;

    cout << "Subtotal: $" << subTtl << endl;
    cout << "Sales Tax: $" << slsTax << endl;
    cout << "Total: $" << total << endl;

    //Exit the program
    return 0;
}

/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 4, 2022, 8:46 PM
 * Purpose: All projects start by using the CPP template. It shows where to place your project
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        tnkSize, //size of gas tank
        ttlDist, //total distance the car can travel on one tank of gas

        mpg; //miles car gets per gallon of gas

    //Initialize Variables here
    tnkSize = 15;
    ttlDist = 375;

    //Map inputs/knowns to the output
    mpg = ttlDist / tnkSize;

    //Display Output
    cout << "The car gets " << mpg << "MPG." << endl;

    //Exit the program
    return 0;
}

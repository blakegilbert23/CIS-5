/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 5, 2022, 5:00 PM
 * Purpose: Predict how much total sales the East Coast division will generate this year if company reaches $8.6 million in sales
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        ttlSls, //total sales
        ecSls;  //East Coast sales

    //Initialize Variables here
    ttlSls = 8.6;

    //Map inputs/knowns to the output
    ecSls = ttlSls * 0.58;

    //Display Output
    cout << fixed << setprecision(2) << endl;

    cout << "If the company generates $8.6 million in sales this year, The East Coast division will generate around $" << ecSls << " million" << endl;

    //Exit the program
    return 0;
}

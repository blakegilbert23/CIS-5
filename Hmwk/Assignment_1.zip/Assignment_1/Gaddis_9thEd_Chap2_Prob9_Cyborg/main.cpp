/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 4, 2022, 8:46 PM
 * Purpose: All projects start by using the CPP template. It shows where to place your project
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //used to setprecision
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here

    //Initialize Variables here

    //Map inputs/knowns to the output

    //Display Output
    cout << " A char uses " << sizeof(char) << " byte of memory." << endl;
    cout << " An int uses " << sizeof(int) << " bytes of memory." << endl;
    cout << " A float uses " << sizeof(float) << " bytes of memory." << endl;
    cout << " A double uses " << sizeof(double) << " bytes of memory." << endl;

    //Exit the program
    return 0;
}

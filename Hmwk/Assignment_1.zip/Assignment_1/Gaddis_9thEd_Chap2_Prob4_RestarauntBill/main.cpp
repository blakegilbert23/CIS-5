/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 4, 2022, 8:46 PM
 * Purpose: Compute the tax and tip on a bill
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //used to setprecision
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        mlCost,  //base cost of meal
        tax,     //tax applied to base meal
        tip,     //tip bases on cost of meal + tax
        ttlBill; //total bill after all costs

    //Initialize Variables here
    mlCost = 88.67;
    tip = 0.20;

    //Map inputs/knowns to the output
    tax = mlCost * 0.0675;
    tip = (mlCost + tax) * 0.20;
    ttlBill = mlCost + tax + tip;

    //Display Output
    cout << fixed << setprecision(2) << endl;

    cout << "Meal cost: $" << mlCost << endl;
    cout << "Tax: $" << tax << endl;
    cout << "Tip: $" << tip << endl;
    cout << "Total Bill: $" << ttlBill << endl;

    //Exit the program
    return 0;
}

/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 4, 2022, 8:46 PM
 * Purpose: Find the average of values
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        num1,
        num2,
        num3,
        num4,
        num5,

        sum,
        avg;

    //Initialize Variables here
    num1 = 28;
    num2 = 32;
    num3 = 37;
    num4 = 24;
    num5 = 33;

    //Map inputs/knowns to the output
    sum = num1 + num2 + num3 + num4 + num5;
    avg = sum / 5;

    //Display Output
    cout << "The average value is: " << avg << endl;

    //Exit the program
    return 0;
}

/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 4, 2022, 8:46 PM
 * Purpose: Find the employees annual pay
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    int
        payAmt,  //paycheck per period
        payPrds, //number of pay periods in one year
        annPay;  //total yearly pay

    //Initialize Variables here
    payAmt = 2200;
    payPrds = 26;

    //Map inputs/knowns to the output
    annPay = payAmt * payPrds;

    //Display Output
    cout << "Annual Pay = $" << annPay << endl;

    //Exit the program
    return 0;
}

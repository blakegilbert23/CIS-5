/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on: Feb. 1st 2022, at 3:00pm
 * Purpose: Compare the answer sheet to the key
 *          and grade
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <fstream>   //File I/O
#include <string.h>    //String Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const unsigned int PERCNV = 100; //percentage conversion

//Function Prototypes
void read(string [],string [], int);
void print(string[], int);
int compare(string [], string [], string [], int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed

    //Declare Variables
    int size=21;
    string key,answers,score;
    string fileKey[size],fileAns[size], fileCW[size];
    float pRight;

    //Initialize or input i.e. set variable values
    read(fileKey,fileAns, size);

    //Score the exam
    pRight=compare(fileKey, fileAns, fileCW, size);

    //Display the outputs
    cout<<"C/W     "; print(fileCW, size);
    cout<<endl<<"Percentage Correct = "<<pRight<<"%"<<endl;

    //Exit stage right or left!
    return 0;
}

void read(string file1[], string file2[], int size){
     for (int i=0; i<size*2; i++)
        i<size
            ? cin >> file1[i]
            : cin >> file2[i-size];
};

void print(string fileKey[], int size) {
    for (int i=1; i<size; i++){
        cout << fileKey[i] << " ";
    }
}

int compare(string fileKey[], string fileAns[], string fileCW[], int size) {
    float correct,wrong;
    correct=wrong=0;

    for (int i=1; i<size; i++){
        if (fileKey[i] == fileAns[i]) {
            fileCW[i] = "C";
            correct++;
        }
        else {
            fileCW[i] = "W";
            wrong++;
        }
    }

    return (correct/(correct+wrong)) * PERCNV;
}

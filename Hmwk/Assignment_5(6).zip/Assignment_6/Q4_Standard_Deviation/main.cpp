/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on: Feb. 1st 2022, at 3:00pm
 * Purpose: Find the standard deviation
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib>   //Srand
#include <ctime>     //Time to set random number seed
#include <cmath>     //Math Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float MAXRAND=pow(2,31)-1;

//Function Prototypes
void  init(float [],int);//Initialize the array
void  print(float [],int,int);//Print the array
float avgX(float [],int, float &);//Calculate the Average
float stdX(float [],int, float);//Calculate the standard deviation

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned>(time(0)));

    //Declare Variables
    const int SIZE=20;
    float test[SIZE];
    float avg;

    //Initialize or input i.e. set variable values
    init(test,SIZE);

    //Display the outputs
    cout << "The average            = " << fixed << setprecision(7) << avgX(test, SIZE, avg) << endl;
    cout << "The standard deviation = " << stdX(test, SIZE, avg) << endl;

    //Exit stage right or left!
    return 0;
}

void init(float arr[],int size) {
    for (int i=0; i<size; i++) cin >> arr[i];
}

void print(float arr[],int size, int lb) {
    for (int i=0; i<size; i++) {
        if (i!=0 && i%lb==0)
            cout << endl;
        cout << arr[i] << " ";
    }
}

float avgX(float arr[], int size, float &avg) {
    float total=0;
    for (int i=0; i<size; i++)
        total += arr[i];
    avg = total/size;
    return avg;
}

float stdX(float arr[], int size, float avg) {
    float sd;
    float test;
    float denom;
    sd = 0.0;
    for (int i=0; i<size; i++)
        sd += ((arr[i] - avg) * (arr[i] - avg));
    sd = sd/(size-1);
    return sqrt(sd);
}

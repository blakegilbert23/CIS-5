/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on: Feb. 1st 2022, at 4:00pm
 * Purpose:  Binary Search and Selection sort
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cstdlib>   //Random Functions
#include <ctime>     //Time Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
void fillAry(int [],int);
void prntAry(int [],int,int);
void selSrt(int [],int);
bool binSrch(int [],int,int,int&);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));

    //Declare Variables
    const int SIZE=100;
    int array[SIZE];
    int indx,val;

    //Initialize or input i.e. set variable values
    fillAry(array,SIZE);

    //Sorted List
    selSrt(array,SIZE);

    //Display the outputs
    prntAry(array,SIZE,10);
    cout << endl << endl;
    cout<<"Input the value to find in the array"<<endl;
    cin>>val;
    if(binSrch(array,SIZE,val,indx))
        cout<<val<<" was found at indx = "<<indx<<endl;

    //Exit stage right or left!
    return 0;
}

void fillAry(int arr[],int size) {
    for (int i=0; i<size; i++) cin >> arr[i];
}

void selSrt(int arr[], int size) {
    int sp, minInd, minVal;

    for (sp=0; sp<(size-1); sp++) {
        minInd = sp;
        minVal = arr[sp];

        for (int index=sp+1; index < size; index++) {
            if (arr[index] < minVal) {
                minVal = arr[index];
                minInd = index;
            }
        }
        arr[minInd] = arr[sp];
        arr[sp]     = minVal;
    }
}

void prntAry(int arr[],int size, int lb) {
    for (int i=0; i<size; i++) {
        if (i!=0 && i%lb==0)
            cout << endl;
        cout << arr[i] << " ";
    }
}

bool binSrch(int arr[], int size ,int val ,int &index) {
    //varaibel declarations
    int
        first,
        last,
        middle,
        pos;
    bool
        found;
    //knowns
    first    = 0;
    last     = size - 1;
    pos = -1;
    found    = false;

    while (!found && first<=last) {
        middle = (first + last) / 2;
        if (arr[middle] == val){
            found = true;
            pos   = middle;
        }
        else if (arr[middle] > val)
            last = middle-1;
        else
            first = middle + 1;
    }

    index = pos;
    return true;
}



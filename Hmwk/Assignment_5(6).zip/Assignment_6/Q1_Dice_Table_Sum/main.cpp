/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created: Feb. 1st 2022, at 12:00pm
 * Purpose: Sum of Dice Table
 *
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const int COLS=6;

//Function Prototypes
void fillTbl(int [][COLS],int);
void prntTbl(const int [][COLS],int);

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    const int ROWS=6;
    int tablSum[ROWS][COLS];

    //Initialize or input i.e. set variable values
    fillTbl(tablSum,ROWS);

    //Display the outputs
    prntTbl(tablSum,ROWS);

    //Exit stage right or left!
    return 0;
}

void fillTbl(int arr[][COLS],int ROWS) {
    for (int i=0; i<ROWS; i++) {
        for (int j=0; j<COLS; j++) arr[i][j] = (i+1) + (j+1);
    }
};

void prntTbl(const int arr[][COLS],int ROWS) {
    cout << "Think of this as the Sum of Dice Table" << endl;
    cout << setw(24) << "C o l u m n s"              << endl;
    cout << setw(6) << "|";
    for (int i=1; i<7; i++) cout << "   " << i;
    cout << endl;
    for (int i=0; i<34; i++) cout << "-";
    cout << endl;

    char letter;
    for (int i=0; i<ROWS; i++) {
        switch(i) {
            case 1:  letter = 'R'; break;
            case 2:  letter = 'O'; break;
            case 3:  letter = 'W'; break;
            case 4:  letter = 'S'; break;
            default: letter = ' '; break;
        }
        cout << letter << "  " << i+1 << " |";

        for (int j=0; j<COLS; j++) {
            cout << setw(4) << arr[i][j];
            if ((j+1)%6 == 0) cout << endl;
        }
    }
}

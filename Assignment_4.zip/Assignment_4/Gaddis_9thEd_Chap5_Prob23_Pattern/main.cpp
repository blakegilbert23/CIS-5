/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 20, 2019, 11:36 PM
 * Purpose:  Output a pattern
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <string>    //String Library
#include <algorithm>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed

    //Declare Variables
    string pattern;
    int pLength;

    //Initialize or input i.e. set variable values
    cin >> pLength;

    //Map inputs -> outputs

    //Display the outputs
    //pattern ascending
    for (int i = 0; i < pLength; i++) {
        pattern += "+";
        cout << pattern << endl << endl;
    }
    //pattern descending
    for (int i = pLength; i > 0; i--) {
        cout << pattern;
        pattern = "";
        for (int j = i; j > 1; j--) pattern += "+";
        if (i > 1) cout << endl << endl;
    }

    //Exit stage right or left!
    return 0;
}

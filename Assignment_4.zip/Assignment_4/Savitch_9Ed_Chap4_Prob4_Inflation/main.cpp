/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 20, 2022, 4:46 PM
 * Purpose: Calculate inflation rate
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)
const unsigned int PERCNV = 100; //percetnage conversion


//Function Prototypes go here
float calcInflation(float cPrice, float yaPrice){
    float rate = (cPrice - yaPrice) / yaPrice;
    return rate * PERCNV;
}

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        cPrice, //current price of item
        yaPrice;     //year ago price of item
    char cont;

    //Initialize Variables here
    do {
        cout << "Enter current price:" << endl;
        cin >> cPrice;
        cout << "Enter year-ago price:" << endl;
        cin >> yaPrice;
        cout << fixed << setprecision(2);
        cout << "Inflation rate: " << calcInflation(cPrice, yaPrice) << "%" << endl << endl;
        cout << "Again:" << endl;
        cin >> cont;
        if (cont == 'y') cout << endl;
    } while (cont == 'y');

    //Map inputs/knowns to the output

    //Display Output

    //Exit the program
    return 0;
}

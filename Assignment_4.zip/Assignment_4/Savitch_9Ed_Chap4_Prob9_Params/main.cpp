/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 20, 2022, 4:46 PM
 * Purpose: Sort a program by the size of its inputs
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here
float twoParams(float num1, float num2){
    return num1 > num2 ? num1 : num2;
}

float threeParams(float num1, float num2, float num3){
    if (num1 > num2 && num1 > num3) return num1;
    if (num2 > num1 && num2 > num3) return num2;
    if (num3 > num1 && num3 > num2) return num3;
}

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float num1, num2, num3;

    //Initialize Variables here
    cout << "Enter first number:" << endl;
    cin >> num1;
    cout << endl;
    cout << "Enter Second number:" << endl;
    cin >> num2;
    cout << endl;
    cout << "Enter third number:" << endl;
    cin >> num3;
    cout << endl;

    //Map inputs/knowns to the output

    //Display Output
    cout << "Largest number from two parameter function:" << endl;
    cout << twoParams(num1, num2) << endl;
    cout << endl;
    cout << "Largest number from three parameter function:" << endl;
    cout << threeParams(num1, num2, num3) << endl;

    //Exit the program
    return 0;
}

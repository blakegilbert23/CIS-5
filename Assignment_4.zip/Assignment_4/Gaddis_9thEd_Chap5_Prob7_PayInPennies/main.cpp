/*
 * File: main.cpp
 * Author: Blake Gilbert
 * Created on January 20, 2019, 1:36 PM
 * Purpose: Find how much money someone would earn if their salary doubled every day
 *
 */


#include <iostream> //Input/Output Library
#include <iomanip>  //Format Library
using namespace std;

//EXECUTION BEGINS HERE!
int main(int argc, char **argv)
{
    //DECLARE VARIABLES
    unsigned int
        days,    //days worked
        sal,     //salary
        ernings, //total earnings
        dPay,    // dollar pay
        pPay;    // penny pay

    //INITIALIZE OR INPUT I.E. SET VARIABLE VALUES
    sal = 1;
    ernings = 0;
    cin >> days;

    //MAP INPUTS -> OUTPUTS
    if (days >= 1) {
        int i = 0;
        while (i < days) {
            ernings += sal;
            sal = sal * 2;
            i++;
        }
        dPay = ernings / 100; //pay in dollars
        pPay = ernings % 100; //remaining pennies
        //DISPLAY OUTPUT
        cout << fixed << setprecision(2);
        cout << "Pay = $" << dPay << "." << setw(2) << setfill('0') << pPay;
    }

    //EXIT STAGE RIGHT OR LEFT!
    return 0;
}

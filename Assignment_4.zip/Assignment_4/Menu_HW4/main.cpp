/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 21th, 2022, 10:51 AM
 * Purpose:  Basic Menu with Functions for exams and homework
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
#include <string>    //String Library
#include <vector>    //Vector Library
#include <algorithm> //Algorithm Library
#include <cmath>     //Math Library
using namespace std; //STD Name-space where Library is compiled

//User Libraries

//Global Constants not Variables
//Math/Physics/Science/Conversions/Dimensions
const float PI = 4 * atan(1);     //Pi equation
const unsigned int PERCNV = 100; //convert to percentage
const float GALCNV = 0.264179;    //convert to gallons

//Function Prototypes
void prob0();
void prob1();
void prob2();
void prob3();
void prob4();
void prob5();
void prob6();
void prob7();
void prob8();
void prob9();
float calcGas();
float calcInflation();
float newPrice();
float twoParams();
float threeParams();

//Code Begins Execution Here with function main
int main(int argc, char** argv) {
    //Set random number seed once here

    //Declare variables here
    int choose;//Choose a problem

    //Initialize variables here
    do{
        cout<<"Choose from the following Menu Items"<<endl;
        cout<<"Problem 0"<<endl;
        cout<<"Problem 1"<<endl;
        cout<<"Problem 2"<<endl;
        cout<<"Problem 3"<<endl;
        cout<<"Problem 4"<<endl;
        cout<<"Problem 5"<<endl;
        cout<<"Problem 6"<<endl;
        cout<<"Problem 7"<<endl;
        cout<<"Problem 8"<<endl;
        cout<<"Problem 9"<<endl;
        cout<<"10 or greater, all negatives to exit"<<endl;
        cin>>choose;

        switch(choose){
            case 0:prob0();break;
            case 1:prob1();break;
            case 2:prob2();break;
            case 3:prob3();break;
            case 4:prob4();break;
            case 5:prob5();break;
            case 6:prob6();break;
            case 7:prob7();break;
            case 8:prob8();break;
            case 9:prob9();break;
            default:cout<<"Exiting the Menu"<<endl;
        }

        cout<<endl<<endl;
    }while(choose>=0 && choose<=9);

    return 0;
}

float calcGas(float lGas, float dist){
    float galUsed = lGas * GALCNV;
    float mpg     = dist / galUsed;
    return mpg;
}

float calcInflation(float cPrice, float yaPrice){
    float rate = (cPrice - yaPrice) / yaPrice;
    return rate * PERCNV;
}

float newPrice(float strtPrc, float rate){
    float prcDiff = strtPrc * (rate / 100);
    return (strtPrc + prcDiff);
}

float twoParams(float num1, float num2){
    return num1 > num2 ? num1 : num2;
}

float threeParams(float num1, float num2, float num3){
    if (num1 > num2 && num1 > num3) return num1;
    if (num2 > num1 && num2 > num3) return num2;
    if (num3 > num1 && num3 > num2) return num3;
}

void prob0(){
    //Declare Variables
    unsigned int number, sum, i;

    //Initialize or input i.e. set variable values
    sum = 0;
    cin >> number;

    //Map inputs -> outputs
    i = 1;
    while (i <= number){
        sum += i;
        i++;
    }

    //Display the outputs
    cout << "Sum = " << sum;
}

void prob1(){
    //DECLARE VARIABLES
    unsigned int
        days,    //days worked
        sal,     //salary
        ernings, //total earnings
        dPay,    // dollar pay
        pPay;    // penny pay

    //INITIALIZE OR INPUT I.E. SET VARIABLE VALUES
    sal = 1;
    ernings = 0;
    cin >> days;

    //MAP INPUTS -> OUTPUTS
    if (days >= 1) {
        int i = 0;
        while (i < days) {
            ernings += sal;
            sal = sal * 2;
            i++;
        }
        dPay = ernings / 100; //pay in dollars
        pPay = ernings % 100; //remaining pennies
        //DISPLAY OUTPUT
        cout << fixed << setprecision(2);
        cout << "Pay = $" << dPay << "." << setw(2) << setfill('0') << pPay;
    }
}

void prob2(){
    //Declare Variables
    int number, bigNum, smlNum;

    //Initialize or input i.e. set variable values
    bigNum = 0;

    //Map inputs -> outputs
    while (number != -99) {
        cin >> number;
        if (number < smlNum && number > 0) smlNum = number;
        if (number > bigNum) bigNum = number;
    }

    //Display the outputs
    cout << "Smallest number in the series is " << setw(1) << smlNum << endl;
    cout << "Largest  number in the series is " << setw(1) << bigNum;
}

void prob3(){
    //Declare Variables
    int    length;
    char   symbol;
    string pattern;

    //Initialize or input i.e. set variable values
    cin >> length >> symbol;

    //Map inputs -> outputs
    //create length of rectangle
    for (int i = 0; i < length; i++) pattern += symbol;
    //create width of rectangle
    for (int i = 0; i < length; i++) {
        cout << pattern;
        if (!(i >= length - 1)) cout << endl;
    }
}

void prob4(){
    //Declare Variables
    string pattern;
    int pLength;

    //Initialize or input i.e. set variable values
    cin >> pLength;

    //Map inputs -> outputs

    //Display the outputs
    //pattern ascending
    for (int i = 0; i < pLength; i++) {
        pattern += "+";
        cout << pattern << endl << endl;
    }
    //pattern descending
    for (int i = pLength; i > 0; i--) {
        cout << pattern;
        pattern = "";
        for (int j = i; j > 1; j--) pattern += "+";
        if (i > 1) cout << endl << endl;
    }
}

void prob5(){
    float
        lGas, //liters of gas used
        dist; //distance traveled
    char cont;

    //Initialize or input i.e. set variable values
    do {
        //enter gas used
        cout << "Enter number of liters of gasoline:" << endl;
        cin >> lGas;
        cout << endl;
        //enter distance traveled
        cout << "Enter number of miles traveled:" << endl;
        cin >> dist;
        cout << endl;
        //output mpg
        cout << "miles per gallon:" << endl;
        cout << fixed << setprecision(2);
        cout << calcGas(lGas, dist) << endl;
        //ask if user wants to repeat
        cout << "Again:" << endl;
        cin >> cont;
        if (cont == 'y') cout << endl;
    } while (cont == 'y');
}

void prob6(){
    //Declare Variables
    float
        lGas1, //liters of gas used for car 1
        lGas2, //liters of gas used for car 2
        dist1, //distance traveled for car 1
        dist2, //distance traveled for car 2
        mpg1,  // mpg for car 1
        mpg2;  // mpg for car 2
    char cont;

    //Initialize or input i.e. set variable values
    do {
        //car 1
        cout << "Car 1" << endl;
        cout << "Enter number of liters of gasoline:" << endl;
        cin >> lGas1;
        cout << "Enter number of miles traveled:" << endl;
        cin >> dist1;
        mpg1 = calcGas(lGas1, dist1);
        cout << fixed << setprecision(2);
        cout << "miles per gallon:" << setw(6) << mpg1 << endl << endl;
        //car 2
        cout << "Car 2" << endl;
        cout << "Enter number of liters of gasoline:" << endl;
        cin >> lGas2;
        cout << "Enter number of miles traveled:" << endl;
        cin >> dist2;
        mpg2 = calcGas(lGas2, dist2);
        cout << fixed << setprecision(2);
        cout << "miles per gallon:" << setw(6) << mpg2 << endl << endl;

        mpg1 > mpg2
            ? cout << "Car 1 is more fuel efficient" << endl << endl
            : cout << "Car 2 is more fuel efficient" << endl << endl;

        //ask if user wants to repeat
        cout << "Again:" << endl;
        cin >> cont;
        if (cont == 'y') cout << endl;
    } while (cont == 'y');
}

void prob7(){
    float
        cPrice,  //current price of item
        yaPrice; //year ago price of item
    char cont;

    //Initialize Variables here
    do {
        cout << "Enter current price:" << endl;
        cin >> cPrice;
        cout << "Enter year-ago price:" << endl;
        cin >> yaPrice;
        cout << fixed << setprecision(2);
        cout << "Inflation rate: " << calcInflation(cPrice, yaPrice) << "%" << endl << endl;
        cout << "Again:" << endl;
        cin >> cont;
        if (cont == 'y') cout << endl;
    } while (cont == 'y');
}

void prob8(){
    //Declare  Variables here
    float
        cPrice,  //current price of item
        yaPrice, //year ago price of item
        iRate;   //inflation rate
    char cont;

    //Initialize Variables here
    do {
        cout << "Enter current price:" << endl;
        cin >> cPrice;
        cout << "Enter year-ago price:" << endl;
        cin >> yaPrice;
        cout << fixed << setprecision(2);
        iRate = calcInflation(cPrice, yaPrice);
        cout << "Inflation rate: " << iRate << "%" << endl << endl;

        cout << "Price in one year: $" << newPrice(cPrice, iRate) << endl;
        cPrice = newPrice(cPrice, iRate);
        cout << "Price in two year: $" << newPrice(cPrice, iRate) << endl << endl;

        cout << "Again:" << endl;
        cin >> cont;
        if (cont == 'y') cout << endl;
    } while (cont == 'y');
}

void prob9(){
    //Declare  Variables here
    float num1, num2, num3;

    //Initialize Variables here
    cout << "Enter first number:" << endl;
    cin >> num1;
    cout << endl;
    cout << "Enter Second number:" << endl;
    cin >> num2;
    cout << endl;
    cout << "Enter third number:" << endl;
    cin >> num3;
    cout << endl;

    //Map inputs/knowns to the output

    //Display Output
    cout << "Largest number from two parameter function:" << endl;
    cout << twoParams(num1, num2) << endl;
    cout << endl;
    cout << "Largest number from three parameter function:" << endl;
    cout << threeParams(num1, num2, num3) << endl;
}



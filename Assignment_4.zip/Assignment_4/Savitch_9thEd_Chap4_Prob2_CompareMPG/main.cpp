/*
 * File: main.cpp
 * Author: Blake Gilbert
 * Created on January 20, 2019, 1:36 PM
 * Purpose:  Calculate mpg of two cars and display which has better gas mileage
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float GALCNV = 0.264179; //gallon conversion

//Function Prototypes
float calcGas(float lGas, float dist){
    float galUsed = lGas * GALCNV;
    float mpg     = dist / galUsed;
    return mpg;
}

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float
        lGas1, //liters of gas used for car 1
        lGas2, //liters of gas used for car 2
        dist1, //distance traveled for car 1
        dist2, //distance traveled for car 2
        mpg1,  // mpg for car 1
        mpg2;  // mpg for car 2
    char cont;

    //Initialize or input i.e. set variable values
    do {
        //car 1
        cout << "Car 1" << endl;
        cout << "Enter number of liters of gasoline:" << endl;
        cin >> lGas1;
        cout << "Enter number of miles traveled:" << endl;
        cin >> dist1;
        mpg1 = calcGas(lGas1, dist1);
        cout << fixed << setprecision(2);
        cout << "miles per gallon:" << setw(6) << mpg1 << endl << endl;
        //car 2
        cout << "Car 2" << endl;
        cout << "Enter number of liters of gasoline:" << endl;
        cin >> lGas2;
        cout << "Enter number of miles traveled:" << endl;
        cin >> dist2;
        mpg2 = calcGas(lGas2, dist2);
        cout << fixed << setprecision(2);
        cout << "miles per gallon:" << setw(6) << mpg2 << endl << endl;

        mpg1 > mpg2
            ? cout << "Car 1 is more fuel efficient" << endl << endl
            : cout << "Car 2 is more fuel efficient" << endl << endl;

        //ask if user wants to repeat
        cout << "Again:" << endl;
        cin >> cont;
        if (cont == 'y') cout << endl;
    } while (cont == 'y');

    //Map inputs -> outputs

    //Display the outputs

    //Exit stage right or left!
    return 0;
}

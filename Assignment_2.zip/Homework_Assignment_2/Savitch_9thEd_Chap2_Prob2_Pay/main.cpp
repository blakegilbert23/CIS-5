/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Write a program that show the annual/monthly salary of an employee after a payraise, as well showing how much retroactive pay they are owed.
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    int
        raPrd; //retroactive period
    float
        raPay,   //retroactive pay due
        cAnnSal, //current annual salary
        cMonSal, //current monthly salary
        nAnnSal, //new annual salary
        nMonSal, //new monthyl salary
        payIncr, //pay increase (percentage)
        payDiff; //monthly pay Difference (dollars)

    //Initialize Variables here
    payIncr = 0.076;
    raPrd = 6;
    cout << "Input previous annual salary." << endl;
    cin >> cAnnSal;

    //Map inputs/knowns to the output
    cMonSal = cAnnSal / 12;
    payDiff = cAnnSal * payIncr;
    nAnnSal = cAnnSal + payDiff;
    nMonSal = nAnnSal / 12;
    raPay = (payDiff / 12) * raPrd;

    //Display Output
    cout << fixed << setprecision(2);
    cout << "Retroactive pay    = $" << setw(7) << raPay << endl;
    cout << "New annual salary  = $" << setw(7) << nAnnSal << endl;
    cout << "New monthly salary = $" << setw(7) << nMonSal;

    //Exit the program
    return 0;
}

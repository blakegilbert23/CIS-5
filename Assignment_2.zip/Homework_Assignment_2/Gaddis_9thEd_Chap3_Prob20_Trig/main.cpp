/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Find the sin, cos, and tan of a user-entered angle
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format Library
#include <math.h>   //Math Library
#include <cmath>    //Math Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)
const float PI = 4*atan(1);
const float RADCNV = PI / 180; //convert from degrees to radians

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        angle,   //user-entered angle
        sinAngl, //sin of user-entered angle
        cosAngl, //cos of user-entered angle
        tanAngl; //tan of user-entered angle

    //Initialize Variables here
    cout << "Calculate trig functions" << endl;
    cout << "Input the angle in degrees." << endl;
    cin >> angle;

    //Map inputs/knowns to the output
    sinAngl = sin(angle * RADCNV); //set's value to sin of angle
    cosAngl = cos(angle * RADCNV); //set's value to cos of angle
    tanAngl = tan(angle * RADCNV); //set's value to tan of angle

    //Display Output
    cout << fixed << setprecision(0) << "sin(" << angle << ") = " << fixed << setprecision(4) << setw(6) << sinAngl << endl;
    cout << fixed << setprecision(0) << "cos(" << angle << ") = " << fixed << setprecision(4) << setw(6) << cosAngl << endl;
    cout << fixed << setprecision(0) << "tan(" << angle << ") = " << fixed << setprecision(4) << setw(6) << tanAngl;

    //Exit the program
    return 0;
}

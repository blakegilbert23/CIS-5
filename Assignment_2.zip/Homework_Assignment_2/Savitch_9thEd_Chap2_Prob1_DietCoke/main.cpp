/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Write a program that determines how many cans of soda are required to kill a human based on weight.
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)
const float GRMCONV = 45359.2;
const unsigned char PERCNV = 100;

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    int
        ldMouse, //lethal dose for a mouse (grams)
        mssMous, //mass of mouse (grams)
        wghtHmn, //weight of the human dieting (grams)
        ldRatio, //lethal dose ratio
        canSize; //can size (grams)
    float
        ldHmn,   //lethal for a human (grams)
        swtnPer, //sweetener ratio (percentage)
        spc,     //sweetner per can (grams)
        ldCans;  //cans required to kill a human

    //Initialize Variables here
    ldMouse = 5;
    mssMous = 35;
    canSize = 350;
    swtnPer = 0.001 * PERCNV;
    cout << "Program to calculate the limit of Soda Pop Consumption." << endl;
    cout << "Input the desired dieters weight in lbs." << endl;
    cin >> wghtHmn;
    wghtHmn *= GRMCONV;

    //Map inputs/knowns to the output
    ldRatio = mssMous / ldMouse;
    ldHmn = wghtHmn / ldRatio;
    spc = canSize * swtnPer;
    ldCans = ldHmn / spc;

    //Display Output
    cout << "The maximum number of soda pop cans" << endl;
    cout << "which can be consumed is " << static_cast<int>(ldCans) << " cans";

    //Exit the program
    return 0;
}

/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:00 PM
 * Purpose: Determine how many total calories were consumed
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float
        ttlCkie, //total cookies
        ttlSrvg, //total servings
        srvgSze, //serving size
        cps,     //calories per serving
        cksEatn, //how many cookies the user has eaten
        eatnCal; //how many calories have been consumed

    //Initialize Variables here
    ttlCkie = 40; //40 total cookies
    ttlSrvg = 10; //10 total servings
    cps = 300;    //300 calories per serving
    cout << "Calorie Counter" << endl;
    cout << "How many cookies did you eat?" << endl;
    cin >> cksEatn;

    //Map inputs/knowns to the output
    srvgSze = ttlCkie / ttlSrvg;
    eatnCal = (cksEatn / srvgSze) * cps;

    //Display Output
    cout << "You consumed " << eatnCal << " calories.";

    //Exit the program
    return 0;
}

/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Display minimum recommended insurance for a property
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    int
        rplCst, //replacement cost
        minIns; //minimum insured amount

    //Initialize Variables here
    cout << "Insurance Calculator" << endl;
    cout << "How much is your house worth?" << endl;
    cin >> rplCst;

    //Map inputs/knowns to the output
    minIns = rplCst * 0.8;

    //Display Output
    cout << "You need $" << minIns << " of insurance.";

    //Exit the program
    return 0;
}

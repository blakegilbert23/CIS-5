/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Write a program that converts Fahrenheit temperatures to Celsius temperatures.
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format Library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    float c, f;

    //Initialize Variables here
    cout << "Temperature Converter" << endl;
    cout << "Input Degrees Fahrenheit" << endl;
    cin >> f;

    //Map inputs/knowns to the output
    c = (5.0 / 9.0) * (f - 32.0);

    //Display Output
    cout << fixed << setprecision(1);
    cout << f << " Degrees Fahrenheit = " << c << " Degrees Centigrade";

    //Exit the program
    return 0;
}

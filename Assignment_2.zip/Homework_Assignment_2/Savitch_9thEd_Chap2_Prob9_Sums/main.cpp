/*
 * File:   main.cpp
 * Author: Blake Gilbert
 * Created on January 13, 2022, 8:46 PM
 * Purpose: Find/sort the sum of all postive numbers, all negative numbers, and all numbers.
 *
 */

//System Level Libraries
#include <iostream> //Input-Output Library
#include <iomanip>  //Format library
using namespace std;

//User Defined Libraries go here

//Global CONSTANTS (not global VARIABLES) go here (constants from Physics, Chemistry, Engineering,  and Conversions between systems of units)

//Function Prototypes go here

//Execution begins here
int main(int argc, char **argv)
{
    //Initialize Random Seed once here

    //Declare  Variables here
    int num1, num2, num3, num4, num5, num6, num7, num8, num9, num10;
    int
        over0,   //holds the sum of all positive numbers
        below0,  //holds the sum of all negative numbers
        allNums; //holds the sum of all numbers

    //Initialize Variables here
    cout << "Input 10 numbers, any order, positive or negative" << endl;
    cin >> num1;
    cin >> num2;
    cin >> num3;
    cin >> num4;
    cin >> num5;
    cin >> num6;
    cin >> num7;
    cin >> num8;
    cin >> num9;
    cin >> num10;
    int numArr[] = {num1, num2, num3, num4, num5, num6, num7, num8, num9, num10};
    over0 = 0;
    below0 = 0;
    allNums = 0;

    //Map inputs/knowns to the output
    for (int i = 0; i < 10; i++)
    {
        if (numArr[i] > 0)
        {
            over0 += numArr[i];
            allNums += numArr[i];
        }
        else if (numArr[i] < 0)
        {
            below0 += numArr[i];
            allNums += numArr[i];
        }
        else
        {
            allNums += numArr[i];
        }
    }

    //Display Output
    cout << "Negative sum = " << setw(3) << below0 << endl;
    cout << "Positive sum = " << setw(3) << over0 << endl;
    cout << "Total sum    = " << setw(3) << allNums;

    //Exit the program
    return 0;
}

/* 
 * File:   main.cpp
 * Author: Blake Gilbert
 *
 * Created on January 25th, 2022, 4:53 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}




